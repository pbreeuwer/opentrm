# OPENTRM — free live market terminal

A Bloomberg-style terminal built entirely on free, public, key-less data:

- **Crypto** — true real-time via Binance public WebSocket (watchlist, candlestick chart, order book, movers)
- **FX** — official ECB reference rates via Frankfurter
- **Stocks** — ~15-min-delayed quotes (Yahoo Finance), fetched every ~10 minutes by a free GitHub Actions job in this repo and served to the page as `docs/quotes.json`

The whole site lives in `docs/` and is served by GitHub Pages. No server, no API keys, no cost.

## Setup (about 2 minutes)

1. **Create a repo** on GitHub (public is easiest for Pages) and push these files to the `main` branch.
2. **Allow the workflow to commit:** Settings → Actions → General → *Workflow permissions* → select **Read and write permissions** → Save.
3. **Run it once:** Actions tab → **quotes** → *Run workflow*. This creates `docs/quotes.json`. After this it runs automatically every ~10 minutes.
4. **Turn on the site:** Settings → Pages → *Deploy from a branch* → branch `main`, folder `/docs` → Save.
5. Open `https://<your-username>.github.io/<repo-name>/` — that's your terminal, live from anywhere.

## Customizing

- **Stock tickers:** edit the `TICKERS` list at the top of `fetch_quotes.py`. Yahoo symbol format: US tickers plain (`AAPL`), Euronext Amsterdam with `.AS` (`ASML.AS`, `ADYEN.AS`), indices with `^` (`^AEX`, `^GSPC`).
- **Refresh rate:** edit the `cron` line in `.github/workflows/quotes.yml`. GitHub's minimum is every 5 minutes, and scheduled runs can lag a few minutes at busy times.
- **Crypto watchlist:** edit the `WL` array near the top of the script block in `docs/index.html`.

## Things to know

- Stock data is **delayed ~15 minutes** by the source, plus the cron interval. Real-time equity feeds are licensed by exchanges and are never legally free — that licensing is most of what a Bloomberg subscription pays for. The crypto panels, by contrast, are genuinely real-time.
- GitHub **pauses scheduled workflows after ~60 days without repo activity**. If the stocks panel goes stale after a quiet stretch, re-enable the workflow from the Actions tab (one click).
- `fetch_quotes.py` uses Yahoo's unofficial endpoints via `yfinance`; they occasionally change. If the job starts failing, updating yfinance (it's installed fresh on every run, so usually self-heals) or swapping the source is straightforward.
- Opening `docs/index.html` directly from disk works for crypto and FX, but browsers block reading the local `quotes.json` over `file://`. Use the Pages URL, or run `python -m http.server` inside `docs/` for local testing.

Nothing in this project is investment advice.
